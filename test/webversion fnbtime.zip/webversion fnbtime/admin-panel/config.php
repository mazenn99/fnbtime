<?php

    $config = [
            'app_name'  => 'Fnbtime',
            'lang'      => 'en',
            'dir'       => 'ltr',
            'admin_mail'=> 'info@fnbtime.com',
    ];