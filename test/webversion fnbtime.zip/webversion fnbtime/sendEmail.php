$<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
//
//// Import PHPMailer classes into the global namespace
//// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
//
require 'vendor/autoload.php';
//
//// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

$sender = "no-reply@fnbtime.com"; //Email of the sender
$password = "ZhSoe-Y31kwl"; //the password
$receiver = "aaa4umail@gmail.com"; // the receiver email

$mail->IsSMTP(); // set mailer to use SMTP
$mail->From = $sender;
$mail->FromName = $sender;
$mail->Host = "sg2plcpnl0079.prod.sin2.secureserver.net"; // specif smtp server
$mail->SMTPSecure= "TLS"; // Used instead of TLS when only POP mail is selected
$mail->Port = 587; // Used instead of 587 when only POP mail is selected 465
$mail->SMTPAuth = true;
$mail->Username = $sender; // SMTP username
$mail->Password = $password; // SMTP password
$mail->AddAddress($receiver, $receiver); //replace myname and mypassword to yours
$mail->AddReplyTo($receiver, $receiver);
$mail->WordWrap = 50; // set word wrap


$mail->IsHTML(true); // set email format to HTML
$mail->Subject = "This is Subject";
$mail->Body = "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
    </head>
        <body>
            Hi mazen , <br>
            Thanks for signing up on Fnbtime <br>
            We're thrilled to have you ! <br>
            To get started , please click the link below to verify we\'ve got your correct email address. <br>
            <a href='https://www.fnbtime.com'>Click here to verify your account.</a> <br>
            Regards, <br>
            <strong>Fnbtime Team</strong>
        </body>
    </html>
";




