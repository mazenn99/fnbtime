
jQuery(function($) {

	"use strict";
		
	$(".counter").countimator();
	
});

