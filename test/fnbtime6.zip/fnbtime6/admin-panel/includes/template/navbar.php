<div class="navbar navbar-inverse">
    <div class="adjust-nav">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

<!--            <a class="navbar-brand" href="https://www.fnbtime.com" target="_blank">-->
<!--                <img src="assets/img/logo-white.png" alt="fnbtime logo" width="61"/>-->
<!--            </a>-->
        </div>

    </div>
</div>