<?php

    $config = [
            'app_name'  => 'Fnbtime',
            'lang'      => 'en',
            'dir'       => 'ltr',
            'no-replay' => 'no-replay@fnbtime.com',
            'admin_mail'=> 'fnbtime@fnbtime.com'
    ];